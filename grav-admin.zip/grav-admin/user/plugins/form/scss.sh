#!/bin/sh
sass --watch -s compressed scss:assets  
